What's changed:

	* Added search bar feature
	
		See index.xhtml file.
		See com.itr.outlet.walmart.control.ProductsView bean.
		See com.itr.outlet.walmart.boundary.WalmartProductService, lines 188 - 222
		
		Few important things here:
			
			The index.xhtml page is built using PrimeFaces Grid CSS. It uses plain 
			HTML tags and some CSS classes (see resources/itr/css/grid.css) to create the page layout. The layout is responsive, for tablets, mobiles and desktop.
			
			You also have a Login link to the scheduled.xhtml page in the top right corner.
			
			The search bar has a clear text button ( X ).
			
			The search form can invoke 3 methods:
			
				- search all (searches for inserted text in product name or category)
				- search only by category
				- search only by product name
				
			For the components attribute icon="fa fa-close" to work properly, you
			need to enable primefaces.FONT_AWESOME icons. This also needs some
			MIME mapping for the respective fonts that they use. 
			See web.xml, lines 17 - 44.
			More info on: https://www.primefaces.org/showcase/ui/misc/fa.xhtml
			
			In case the search does not found any record, an "No records found."
			message is displayed. See index.xhtml, line 54.
			
			Lines 52 - 66 in the index.xhtml file displays the products found,
			that panel is auto-updated at each AJAX request fired.
			
			Lines 68 - 79 in the index.xhtml file are used for page navigation,
			there are two buttons, "Previous Page" and "Next Page".
			
			In the com.itr.outlet.walmart.control.ProductsView bean, the page size
			for displaying the products is set to 3. CHANGE THIS TO THE NUMBER OF
			ITEMS THAT YOU WISH TO DISPLAY ON A PAGE.
			
			In the WalmartProductService, lines 188 - 222, we create the query 
			based on the filter (search in all, search in category, search in 
			product name) and the inserted search text. The resulted query may 
			look like bellow:
			
			SELECT * FROM walmartproduct WHERE status = "ACTIVE" AND productName LIKE "%home%";
			
			Basically, it searches if the productName column contains the text "home"
			More info: https://www.w3schools.com/sql/sql_like.asp
			
			Keep in mind that the pagination is made at the database layer,
			meaning that we only extract what we display. We have a pagination of
			3 items, we extract and display 3 items, then on "Next Page" button
			action, we search for the next 3 items, extract them and display.
			
			On the web, there are other examples where people extract loads of 
			data from the database, and then use JSF to display only 10 of the 
			items. This means that they have for ex. 50 records in memory, from which
			only 10 are shown. This is not a good practice and causes several 
			performance issues.
	
	* Added a public main view visible to everybody
	
		Add index.xhtml page and change welcome page from web.xml to this one, 
		rename index.html to old_index.html
	
	* Enlarge barcode generated image
		
		See resources/itr/css/scheduled.css, lines 17 - 24

			#productTableForm img:first-child {
				    width: 74px;
					height: 90px;
			} => This caused all images from product table to have have a fixed size,
			including the barcode.
			
		See scheduled.xhtml page, line 178
		
			Add width and height to our image, since we removed the CSS from above
			
		See scheduled.xhtml page, line 265
		
			There is no need for a panel grid, which may inherit CSS from other PrimeFaces
			components, so we just add the barcode.
			
			Add .row-exp td { text-align: left;	} to resources/itr/css/scheduled.css
			in order to align the barcode image to left.
