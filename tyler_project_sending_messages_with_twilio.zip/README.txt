What's changed:

	* Validate phone numbers with Twilio when an employee registers
	
		Added AJAX status in case the process last longer, see login.xhtml, lines 57 - 61
		Added tooltip with examples of accepted phone numbers, see login.xhtml, lines 98 - 104
		Added custom phone validator which uses Twilio for validating phone numbers
			See login.xhtml, lines 138 - 141
			See com.validators.PhoneNumberValidator
			See com.itr.twilio.TwilioHelper, lines 16 - 44
	
	* Sending messages with Twilio
	
		See scheduled.xhtml, lines 257 - 261
		See ScheduledWalmartProductBean, lines 44 - 45, 261 - 264
		See com.itr.twilio.TwilioHelper, lines 46 - 61
		See com.itr.twilio.TwilioCredentials
		See com.itr.outlet.walmart.boundary.MessageService
		
			The sendMessagesAsynchronously() method receives a list of active products, which means that when you wish
			to send SMS only for one active product, just pass to the method a list with a single WalmartProduct, as
			below: 
			
				messageService.sendMessagesAsynchronously(Arrays.asList(selectedWalmartProduct));
			
			If you wish to send multiple WalmartProducts, selecting products with checkbox, you would probably have something
			like:
			
				private List<WalmartProduct> selectedWalmartProducts;
				
			And then, when you click a button, just invoke a method that sends them to MessageService:
			
				messageService.sendMessagesAsynchronously(selectedWalmartProducts);
		
		See com.itr.outlet.walmart.boundary.EmployeeService, lines 63 - 66
		
